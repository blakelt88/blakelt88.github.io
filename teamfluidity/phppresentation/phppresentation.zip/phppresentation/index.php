<!DOCTYPE html>
<html>
<head>
<title>PHP Variables Presentation</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

<!-- CSS -->
<link rel="stylesheet" href="main.css">
</head>


<body class="index">
<h1>PHP Variables Presentation</h1><br>
<div class="row">
	<iframe src="https://docs.google.com/presentation/d/1ijF1FcomnCVu51LCAalVQqSpStPKZqlQMCk8Hk9Hh5Q/embed?start=false&loop=true&delayms=10000" frameborder="0" width="1440" height="839" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe><br><br>
	<h2>Let's Practice!</h2>
	<p>Feel free to pause the video and follow along! Attached is this very template I am using. Click <a href="">here</a> to download! Once downloaded paste it into our htdocs folder of xammp and then open it up in your text editor.</p>
	<div class="col-md-6">
	<h3>Variable Declaration</h3>
	<p>(PHP variables can only be seen on the backend.)</p>
	<!-- Double Quote Declaration -->
	<!-- PHP "" variable goes below -->
	
	</div>
	<div class="col-md-6">
	<h3>Variable Output</h3>
	<!-- Double Quote Output -->
	<!-- PHP "" echo goes below -->
	
	</div>
	<div class="col-md-6">
	<!-- Single Quote Declaration -->
	<!-- PHP '' variable goes below -->
	
	</div>
	<div class="col-md-6">
	<!-- Single Quote Output -->
	<!-- PHP '' echo goes below -->
	</div>
	<div class="col-md-12">
	<h2>Let's Try Concatenation Of Variable Output!</h2>
	</div>
	<div class="col-md-6">
	<!-- PHP declared variable goes below -->
	
	</div>
	<div class="col-md-6">
	<!-- Ouput goes below! -->
	
	</div>
	</div>
	<div class="emptyfooter">
	
	</div>
</body>
</html>