<?php

$product_description = $_POST['product_description'];
$list_price = $_POST['list_price'];
$discount_percent = $_POST['discount_percent'];
$discount_amount = round($list_price * ($discount_percent * .01), 2);
$discount_price = round($list_price - $discount_amount, 2);
$sales_tax_rate = "8%";
$sales_tax_amount = round($discount_price * .08, 2);

$error = "";
$error2 = "";
$error3 = "";

if ( empty($product_description)) {
    $error = "*PD ERROR: Cannot be blank";
}

if ( empty($list_price) || !is_numeric($list_price)) {
    $error2 = "*LP ERROR: Must be a number";
}

if ( empty($discount_percent) || !is_numeric($discount_percent)) {
    $error3 = "*DP ERROR: Must be a number";
}

?>



<!DOCTYPE html>
<html>
<head>
    <title>Product Discount Calculator</title>
    <link rel="stylesheet" type="text/css" href="main.css">
    <style>
        .red {
            color: red;
        }
    </style>
</head>
<body>
    <main>
        <h1>Product Discount Calculator</h1>

        <label>Product Description:</label>
        <span><?php echo $product_description; ?></span><span class="red"><?php echo $error; ?></span><br>

        <label>List Price:</label>
        <span><?php echo "$ " . $list_price; ?></span><span class="red"><?php echo $error2; ?></span><br>

        <label>Standard Discount:</label>
        <span><?php echo $discount_percent . "%"; ?></span><span class="red"><?php echo $error3; ?></span><br>

        <label>Discount Amount:</label>
        <span><?php echo "$ " . $discount_amount; ?></span><br>

        <label>Discount Price:</label>
        <span><?php echo "$ " . $discount_price; ?></span><br><br>
        
        <label>Sales Tax Rate:</label>
        <span><?php echo $sales_tax_rate; ?></span><br>
        
        <label>Sales Tax Amount:</label>
        <span><?php echo "$ " . $sales_tax_amount; ?></span><br>


    </main>
</body>
</html>